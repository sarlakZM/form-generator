import { createServer, Model } from "miragejs"

export function makeServer({ environment = "test" } = {}) {
  let server = createServer({
    environment,

    models: {
      form: Model,
    },

    seeds(server) {
    },

    routes() {
      this.namespace = "api"

      this.get("/forms", (schema: any) => {
        return schema.forms.all()
      })
      this.post('/forms', (schema: any, request) => {
        const attrs = JSON.parse(request.requestBody);
        return schema.forms.create(attrs);
      });
    },
  })

  return server
}
