import { Checkbox, FormControlLabel, TextField } from "@mui/material"
import { Element } from "../../models/form.types"

export const RenderFieldForm = (elementProps: Element) => {
    const fields = {
      'text': <TextField id={elementProps?.id} label={elementProps?.label} required={elementProps?.isRequired} variant="standard" />,
      'checkbox': <FormControlLabel id={elementProps?.id} label={elementProps?.label} control={<Checkbox defaultChecked={elementProps?.isRequired} />} />,
    }
    return fields[elementProps.type] 
  }