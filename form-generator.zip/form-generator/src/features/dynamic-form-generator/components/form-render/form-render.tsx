
import { formStore } from "../../store/store";
import { Form } from "../../models/form.types";
import { RenderFieldForm } from "./field-render";
import { useEffect, useState } from "react";


const FormsRender = () => {
  const { forms } = formStore();
  // let [formsApi, setFormsApi] = useState([])
  const renderForm = [...forms]
  // useEffect(() => {
  //   getFormsFromApi().then(
  //     response => setFormsApi(response as any)
  //   )
  // }, [])

  return (
    <div>
      {renderForm.map( (form: Form, index) => {
        return (
          <div key={index}>
            <h3>Form Name: {form.name}</h3>
            {form.elements.map((element, index) => {
              return (
                <div key={index}>
                     <RenderFieldForm {...element} /> 
                </div>
              );
            })}

            <hr />
          </div>
        );
      })}
    </div>
  );
}
export default FormsRender;



