import { act, render, screen } from "@testing-library/react";
import * as React from 'react';
import FormGenerator from "./form-generator";


describe('Component: Form Generator', () => {
  it('renders App component', () => {
    render(<FormGenerator />);
  });
});