import { useForm, useFieldArray } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import { Button, Divider, IconButton, Stack} from "@mui/material"
import RemoveCircleIcon from '@mui/icons-material/RemoveCircle';
import AddCircleIcon from '@mui/icons-material/AddCircle';

import { validationFormGenerator } from "../../services/form-generator.services"
import { IFormGenerator } from "../../models/form-generator.types"
import { CustomTextField } from "../../../../core/components/CustomTextField";
import { CustomSelectField } from "../../../../core/components/CustomSelectField";
import { CustomCheckboxField } from "../../../../core/components/CustomCheckboxField";
import { formStore } from "../../store/store";


function FormGenerator() {
  const { setForm } = formStore();

  const defaultFormValues: IFormGenerator= {
    name: 'Form Name',
    elements: [{
      label: 'Field Name',
      type: 'text',
      isRequired: false
    }]
  }
  const { control, handleSubmit, formState: { errors }} = useForm<IFormGenerator>({
    resolver: yupResolver(validationFormGenerator),
    defaultValues : defaultFormValues,
  });
  const { fields, append, remove } = useFieldArray({
    control,
    name: "elements"
  });
  
  const onSubmit = (data: any) => {
    setForm(data)
  };

  return (
     <form onSubmit={handleSubmit(onSubmit)}>
      <Stack
        spacing={{ xs: 1, sm: 2 }}
        direction="column"
        useFlexGap
        sx={{ flexWrap: 'wrap' }}
      >
      <CustomTextField  name="name" control={control} rules={{ required: true }}/>
        {fields.map((item, index) => (
            <Stack key={item.id}
              direction="row"
              spacing={2}
              divider={<Divider orientation="vertical" flexItem />}
            >
              <CustomTextField  name={`elements.${index}.label`}  
                                control={control} 
                                rules={{ required: true }}/>
              <CustomSelectField  name={`elements.${index}.type`} 
                control={control} 
                rules={{ required: true }}
                defaultValue ={'text'}
                options = {['text', 'checkbox']}
              />
              <CustomCheckboxField 
                  name={`elements.${index}.isRequired`}
                  control={control}
                  rules={{ required: false }}
                  label="Required"
              />

            <IconButton aria-label="delete" size="large" onClick={() => remove(index)}>
              <RemoveCircleIcon />
            </IconButton>
            <IconButton aria-label="add" size="large" onClick={() => append(defaultFormValues.elements[index])}>
              <AddCircleIcon />
            </IconButton>
            </Stack>
        ))}
      </Stack>
      <Button variant="contained"  type="submit" >Submit</Button>
    </form>
  )
}



export default FormGenerator;

