import * as yup from "yup"

export const validationFormGenerator = yup.object().shape({
    name: yup.string().max(100).required("Name is a required field"),
    elements: yup
      .array()
      .of(
        yup.object({
          type: yup.string<'text' | 'checkbox'>().nonNullable().defined(),
          label: yup.string().required("Label is a required field"),
          isRequired: yup.boolean().optional(),
        }),
      )
      .required(),
  })   