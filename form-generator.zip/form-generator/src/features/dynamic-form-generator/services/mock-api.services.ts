
import { Form } from "../models/form.types"

export async function setFormToApi(form: Form){
    const response = await fetch('/api/forms', {
        method: 'POST',
        body: JSON.stringify(form)
      })
      .then((res) => res.json())
      .then((json) => json.forms)
    return response
}

export async function fetchFormsFromApi(){
    const response = await fetch('/api/forms')
    .then((res) => res.json())
    .then((json) => json.forms)
    return response
}

