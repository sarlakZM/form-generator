import * as yup from "yup"


  export const validationSchemaForm = yup.object().shape({
    id: yup.string().max(100).required(),
    name: yup.string().max(100).required("Name is a required field"),
    elements: yup
      .array()
      .of(
        yup.object({
          id: yup.string().min(50).required(),
          type: yup.string<'text' | 'checkbox'>().nonNullable().defined(),
          label: yup.string().required("Label is a required field"),
          isRequired: yup.boolean().optional(),
          choices: yup
                .array()
                .of(
                    yup.object({
                        id: yup.string().required(),
                        name: yup.string().required(),
                    })).optional()
        }),
      )
      .required(),
  })  


  
