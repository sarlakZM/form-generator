import { UUID } from "../../../core/utils/utils";
import { IElementGenerator } from "../models/form-generator.types";
import { Form } from "../models/form.types";

export const formDataConvertor = ({ name, elements}: any): Form => {
    const newForm: Form = {
        id : UUID(),
        name: name,
        elements: elements.map((element: IElementGenerator) =>  ({ ...element, id: UUID() }))

    }
    return newForm;
}