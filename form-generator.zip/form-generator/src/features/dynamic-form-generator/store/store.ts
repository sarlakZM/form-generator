import { create } from "zustand";
import { Form } from "../models/form.types";
import { IFormGenerator } from "../models/form-generator.types";
import { formDataConvertor } from "../utils/utils";
// import { setFormToApi } from "../services/mock-api.services";

interface IForms {
    forms :Form[],   
}
export const formStore = create((set: any, get: any) => ({
  forms: [],
  setForm: (form: IFormGenerator) =>
    set((state : IForms) => {
      // setFormToApi({ ...formDataConvertor(form)})
      return ({ forms: [...state.forms, { ...formDataConvertor(form) }] })
    }),
  remove: (index: string) =>
    set((state : IForms) => ({
        forms: state.forms.filter(({id}) => id !== index)
    })),
}));

