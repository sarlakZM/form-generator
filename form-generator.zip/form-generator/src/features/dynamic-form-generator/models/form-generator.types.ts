import { Control, FieldValues, Path, PathValue, RegisterOptions } from "react-hook-form";

export interface IFormGenerator {
    name: string;
    elements: IElementGenerator[];
}


export interface IElementGenerator {
type: 'text' | 'checkbox';
label: string;
isRequired?: boolean;
}


export interface ICustomFieldProps<T extends FieldValues> {
    name: Path<T>;
    rules?: RegisterOptions<T>;
    control?: Control<T>;
    defaultValue?: PathValue<T, Path<T>>;
    options?: string[];
    label?: string;
}




