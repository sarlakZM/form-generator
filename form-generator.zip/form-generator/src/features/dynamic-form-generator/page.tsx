import { formStore } from "./store/store";
import FormGenerator from "./components/form-generator/form-generator";
import FormsRender from "./components/form-render/form-render";


const DynamicFormGenerator = () => {
 
  return (
    <>
    <FormGenerator />
    <hr/>
    <FormsRender/>
    </>
  )
}

export default DynamicFormGenerator;



