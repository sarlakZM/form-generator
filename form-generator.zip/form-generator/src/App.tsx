import './App.css'
import DynamicFormGenerator from './features/dynamic-form-generator/page'
import { makeServer } from "./server"

function App() {
  const mode = `${process.env.NODE_ENV}`;
  if (mode=== "development") {
    makeServer({ environment: "development" })
  }
  return (
    <>
      <DynamicFormGenerator />
    </>
  )
}

export default App
