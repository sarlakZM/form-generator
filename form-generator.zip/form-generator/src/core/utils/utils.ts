
export const UUID = () => window.crypto.randomUUID();
