import { FormControl, Input, TextField } from "@mui/material"
import { Control, Controller, FieldValues, Path, PathValue, RegisterOptions } from "react-hook-form"
import { ICustomFieldProps } from "../../features/dynamic-form-generator/models/form-generator.types";


export const CustomTextField =  <T extends FieldValues>({ name, label, defaultValue, control=undefined, rules}:ICustomFieldProps<T>) => {
    return (
      <FormControl>
        <Controller
          name={name ?? label}
          defaultValue={defaultValue}
          control={control}
          rules={rules}
          render={({ field, fieldState: { error } }) => (
            <>
              <TextField
                {...field}
                error = { error ? true : false}
               />
            </>
          )}
        />

      </FormControl>
    );
  };