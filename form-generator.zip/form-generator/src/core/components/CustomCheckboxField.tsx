import { Checkbox, FormControl, FormControlLabel, Input } from "@mui/material"
import { Control, Controller, FieldValues, Path, PathValue, RegisterOptions } from "react-hook-form"
import { ICustomFieldProps } from "../../features/dynamic-form-generator/models/form-generator.types";


export const CustomCheckboxField = <T extends FieldValues>({ name, control, rules, label}:ICustomFieldProps<T>) => {
    return (
      <FormControl>
            <Controller
                name={name}
                control={control}
                rules={rules}
                render={({ field }) => 
                <FormControlLabel control={<Checkbox {...field} />} label= {label} />

              }
            />
      </FormControl>
    );
  };