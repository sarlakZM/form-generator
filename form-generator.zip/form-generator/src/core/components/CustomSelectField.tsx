import { TextsmsTwoTone } from "@mui/icons-material";
import { FormControl, Input, MenuItem, Select } from "@mui/material"
import { Control, Controller, CustomElement, FieldValues, Path, PathValue, RegisterOptions } from "react-hook-form"
import { ICustomFieldProps } from "../../features/dynamic-form-generator/models/form-generator.types";


export const CustomSelectField = <T extends FieldValues>({ name, defaultValue, control, options, rules}:ICustomFieldProps<T>) => {
    return (
      <FormControl>
          <Controller
            control={control}
            name={name}
            defaultValue={defaultValue}
            rules= {rules}
            render={({ field }) => (
              <Select {...field}>
              {options?.map((value) => (
                  <MenuItem key={value} value={value}>
                    {value}
                  </MenuItem>
              ))}
              </Select>
            )}
        />
      </FormControl>
    );
  };